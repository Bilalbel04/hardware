#!/bin/bash

# Colores
Cyan="\e[36m"
Normal="\e[0m"

#Recopilar informació
CPU_NAME=$(lscpu | grep "Nombre del modelo:" | tr -s " " | cut -d" " -f4-)
TOTAL_RAM=$(dmidecode --type memory | grep "Size:" | grep -v "Volatile" | grep "GB" | cut -d" " -f2 | paste -sd+ | bc)
MAX_RAM=$(dmidecode --type memory | grep "Maximum Capacity:" | tr -s "" | cut -d" " -f3)
GRAFICA=$(lspci | grep "VGA" | cut -d" " -f5-)
PLACA_BASE=$(dmidecode --type system | grep "Manufacturer" | cut -d" " -f2-)
PLACA_MODELO=$(dmidecode --type system | grep "Product Name:" | cut -d" " -f3-)
CANTIDAD_DISCOS=$(lsblk | grep "disk" | tr -s " " | cut -d" " -f6 | wc -l)

# Salida por pantalla 
# Limpieza de consola
clear
# Informacion
echo -e "${Cyan}Marca y  modelo de la CPU:${Normal} ${CPU_NAME}"
echo -e "${Cyan}Memoria RAM total Instalada:${Normal} ${TOTAL_RAM} GB ${Normal}"
echo -e "${Cyan}Memoria RAM maxima instalable:${Normal} ${MAX_RAM}"
echo -e "${Cyan}Marca y modelo de grafica:${Normal} ${GRAFICA}"
echo -e "${Cyan}Marca y modelo de Placa Base:${Normal} ${PLACA_BASE}${PLACA_MODELO}"
echo -e "${Cyan}Numero de disco durs insertados:${Normal} ${CANTIDAD_DISCOS}"

